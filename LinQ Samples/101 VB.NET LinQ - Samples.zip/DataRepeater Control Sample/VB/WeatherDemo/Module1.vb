Module ForecastTypes


    Public Const Cloudy As String = "Cloudy"
    Public Const Fog As String = "Fog"
    Public Const Clear As String = "Clear"
    Public Const Flurries As String = "Flurries"
    Public Const Snow As String = "Snow"
    Public Const Shower_Clear As String = "Showers / Clear"
    Public Const Rain As String = "Rain"
    Public Const Fair As String = "Fair"
    Public Const Sprinkles As String = "Sprinkles"
    Public Const AM_Rain As String = "AM Rain"

End Module
